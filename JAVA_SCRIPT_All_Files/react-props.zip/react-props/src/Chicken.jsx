import "./Chicken.css";
function Chicken() {
  return <p className="Chicken">Bock Bock Bock!</p>;
}

export default Chicken;
