import Slots from "./Slots";
import "./App.css";

function App() {
  return (
    <div>
      <Slots val1="🍌" val2="🍌" val3="🍌" />
    </div>
  );
}

export default App;
